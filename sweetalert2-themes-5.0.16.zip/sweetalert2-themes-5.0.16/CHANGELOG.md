## [5.0.16](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.15...v5.0.16) (2024-01-11)


### Bug Fixes

* upgrade deps ([db7f0dc](https://github.com/sweetalert2/sweetalert2-themes/commit/db7f0dc656547f524b30fea833d1e182a75f3aaa))

## [5.0.15](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.14...v5.0.15) (2022-11-20)


### Bug Fixes

* use zx for tools/*.mjs scripts ([3a04200](https://github.com/sweetalert2/sweetalert2-themes/commit/3a04200f27ba11073d65e752c41cb8d665a63623))

## [5.0.14](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.13...v5.0.14) (2022-11-07)


### Bug Fixes

* upgrade deps ([0aa2c38](https://github.com/sweetalert2/sweetalert2-themes/commit/0aa2c38ef16b33709917cbea974393292dc28568))

## [5.0.13](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.12...v5.0.13) (2022-10-30)


### Bug Fixes

* upgrade deps ([9964bf0](https://github.com/sweetalert2/sweetalert2-themes/commit/9964bf091490f1be8fa7174c1f4389cac02904d3))

## [5.0.12](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.11...v5.0.12) (2022-08-20)


### Bug Fixes

* upgrade deps ([541d1a2](https://github.com/sweetalert2/sweetalert2-themes/commit/541d1a2624c49667dd70aa4895540839353353e5))

## [5.0.11](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.10...v5.0.11) (2022-05-09)


### Bug Fixes

* upgrade deps ([bf84b5a](https://github.com/sweetalert2/sweetalert2-themes/commit/bf84b5a45b51185ab196f227ce8a5492828e033b))

## [5.0.8](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.7...v5.0.8) (2021-11-19)


### Bug Fixes

* upgrade deps ([609fc2b](https://github.com/sweetalert2/sweetalert2-themes/commit/609fc2bc25948688e9150737d959bc560353f2ca))

## [5.0.7](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.6...v5.0.7) (2021-10-21)


### Bug Fixes

* remove node_modules from import path ([#82](https://github.com/sweetalert2/sweetalert2-themes/issues/82)) ([0e9792c](https://github.com/sweetalert2/sweetalert2-themes/commit/0e9792c62d628da68c93b3305e14c6e659c585c6))

## [5.0.6](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.5...v5.0.6) (2021-10-19)


### Bug Fixes

* do not use tilde ~ ([#80](https://github.com/sweetalert2/sweetalert2-themes/issues/80)) ([3f76134](https://github.com/sweetalert2/sweetalert2-themes/commit/3f76134d9ae0c648aad89897a7d6468838003ca6))

## [5.0.5](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.4...v5.0.5) (2021-09-22)


### Bug Fixes

* bump sweetalert2 to latest ([5b909f7](https://github.com/sweetalert2/sweetalert2-themes/commit/5b909f7c43fbf6cff46241a905d94111005c3742))

## [5.0.4](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.3...v5.0.4) (2021-09-08)


### Bug Fixes

* bump sweetalert2 to latest ([7a88c75](https://github.com/sweetalert2/sweetalert2-themes/commit/7a88c75c23239d4b525b14f7818e3e0739e3e8f2))

## [5.0.3](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.2...v5.0.3) (2021-09-03)


### Bug Fixes

* bump sweetalert2 to latest ([7faf4b8](https://github.com/sweetalert2/sweetalert2-themes/commit/7faf4b884adc58780f9936f5ab72031a86354be4))

## [5.0.2](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.1...v5.0.2) (2021-07-23)


### Bug Fixes

* bump sweetalert2 to latest ([c2be602](https://github.com/sweetalert2/sweetalert2-themes/commit/c2be602639c761bc12548941bc05ed12757d2e47))

## [5.0.1](https://github.com/sweetalert2/sweetalert2-themes/compare/v5.0.0...v5.0.1) (2021-06-27)


### Bug Fixes

* use math.div() ([a4a2e1d](https://github.com/sweetalert2/sweetalert2-themes/commit/a4a2e1d61514cbf7b70de4020af7d28ca9cbf8d8))

# [5.0.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v4.0.5...v5.0.0) (2021-05-16)


* BREAKING CHANGE: Upgrade to SweetAlert v11 ([c446447](https://github.com/sweetalert2/sweetalert2-themes/commit/c44644796174d470d9cd27196c9476229c569496))


### BREAKING CHANGES

* Upgrade to SweetAlert v11

## [4.0.5](https://github.com/sweetalert2/sweetalert2-themes/compare/v4.0.4...v4.0.5) (2021-04-19)


### Bug Fixes

* bump sweetalert2 to latest ([c1790aa](https://github.com/sweetalert2/sweetalert2-themes/commit/c1790aaf695feccae0ebda44cacd2aa3927ee608))

## [4.0.4](https://github.com/sweetalert2/sweetalert2-themes/compare/v4.0.3...v4.0.4) (2021-04-19)


### Bug Fixes

* bump sweetalert2 to latest ([cee4665](https://github.com/sweetalert2/sweetalert2-themes/commit/cee4665d822f74adf61cf4c56a1bf84ef2dfe0ef))

## [4.0.3](https://github.com/sweetalert2/sweetalert2-themes/compare/v4.0.2...v4.0.3) (2021-02-18)


### Bug Fixes

* bump sweetalert2 to latest ([2174654](https://github.com/sweetalert2/sweetalert2-themes/commit/217465453b67e826da10da16f943d2cfb054bc1e))

## [4.0.2](https://github.com/sweetalert2/sweetalert2-themes/compare/v4.0.1...v4.0.2) (2021-01-25)


### Bug Fixes

* bump sweetalert2 to latest ([f2fc326](https://github.com/sweetalert2/sweetalert2-themes/commit/f2fc32686470dbff843cbf516e8ab0e85d634531))

## [4.0.1](https://github.com/sweetalert2/sweetalert2-themes/compare/v4.0.0...v4.0.1) (2020-10-30)


### Bug Fixes

* bump sweetalert2 to latest ([d2cd0ae](https://github.com/sweetalert2/sweetalert2-themes/commit/d2cd0aef6f8202370c04c24399cc1749d39a4ad9))

# [4.0.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.2.0...v4.0.0) (2020-09-08)


* BREAKING CHANGE: SweetAlert2 v10 🚀 ([5bd74e6](https://github.com/sweetalert2/sweetalert2-themes/commit/5bd74e6bcdc2de7d3b2c08ead7d4934fc09fa541))


### BREAKING CHANGES

* SweetAlert2 v10 🚀

# [3.2.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.1.4...v3.2.0) (2020-06-20)


### Features

* add Bulma theme ([#57](https://github.com/sweetalert2/sweetalert2-themes/issues/57)) ([9212725](https://github.com/sweetalert2/sweetalert2-themes/commit/92127258f7a267cc1ec6a6245a05c4bc1b3afda3)), closes [#13](https://github.com/sweetalert2/sweetalert2-themes/issues/13) [#13](https://github.com/sweetalert2/sweetalert2-themes/issues/13) [#13](https://github.com/sweetalert2/sweetalert2-themes/issues/13) [#13](https://github.com/sweetalert2/sweetalert2-themes/issues/13)

## [3.1.4](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.1.3...v3.1.4) (2020-03-16)


### Bug Fixes

* **dark:** timer-progress-bar color ([008182a](https://github.com/sweetalert2/sweetalert2-themes/commit/008182ac628e8085fd9ff85aa5dd654651135c17))

## [3.1.3](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.1.2...v3.1.3) (2020-03-16)


### Bug Fixes

* bump sweetalert2 to ^9.10.1 ([613bac6](https://github.com/sweetalert2/sweetalert2-themes/commit/613bac67db93bcb8fdc3e11e578cbea4135f59e3))

## [3.1.2](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.1.1...v3.1.2) (2020-03-07)


### Bug Fixes

* **bootstrap-4:** remove padding and border-bottom from .swal2-header ([1afddc0](https://github.com/sweetalert2/sweetalert2-themes/commit/1afddc08682b9a2e4554cdfe62c5be20eac2876e)), closes [#52](https://github.com/sweetalert2/sweetalert2-themes/issues/52)
* **wordpress-admin:** set $swal2-container-padding to single value ([06eeed4](https://github.com/sweetalert2/sweetalert2-themes/commit/06eeed4ae21c7c27bfc1b56d2629e5249ae3c74d)), closes [#51](https://github.com/sweetalert2/sweetalert2-themes/issues/51)

## [3.1.1](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.1.0...v3.1.1) (2020-02-22)


### Bug Fixes

* bump sweetalert2 to latest ([2168f31](https://github.com/sweetalert2/sweetalert2-themes/commit/2168f314dd1601a9bb2cc79dd897d910b9bd0bba))

# [3.1.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.0.7...v3.1.0) (2019-12-10)


### Features

* add WordPress admin theme ([#47](https://github.com/sweetalert2/sweetalert2-themes/issues/47)) ([84263a1](https://github.com/sweetalert2/sweetalert2-themes/commit/84263a117c697e45b52972dc72d5b70757a31b45))

## [3.0.7](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.0.6...v3.0.7) (2019-12-01)


### Bug Fixes

* **dark:** apply dark backgorund to toast ([#44](https://github.com/sweetalert2/sweetalert2-themes/issues/44)) ([6324ba6](https://github.com/sweetalert2/sweetalert2-themes/commit/6324ba6b2af633f4ce296c0cb9e06e88ee6a141d))

## [3.0.6](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.0.5...v3.0.6) (2019-11-30)


### Bug Fixes

* bump sweetalert2 to ^9.4.0 ([ca2477b](https://github.com/sweetalert2/sweetalert2-themes/commit/ca2477beba7db88899d815e4c814f81c5f51f635))

## [3.0.5](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.0.4...v3.0.5) (2019-11-15)


### Bug Fixes

* buttons box-shadow ([8d015be](https://github.com/sweetalert2/sweetalert2-themes/commit/8d015bed60ddb3a844ca9507157e9b6dc0c24773))

## [3.0.4](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.0.3...v3.0.4) (2019-11-15)


### Bug Fixes

* **borderless:** use $swal2-toast-background variable ([996a605](https://github.com/sweetalert2/sweetalert2-themes/commit/996a605e920acd518c426585bf7696148622457f))
* **dark:** remove unnecessary styles ([8ffac42](https://github.com/sweetalert2/sweetalert2-themes/commit/8ffac4251fbb9ed55162ba26c30259f7c7f680c0))
* depend on sweetalert2@^9.3.8 ([a0fba6e](https://github.com/sweetalert2/sweetalert2-themes/commit/a0fba6e4cb43fdd87dda5bb05b430be31a121fd5))

## [3.0.3](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.0.2...v3.0.3) (2019-11-14)


### Bug Fixes

* **dark:** footer-border-color ([a4f590e](https://github.com/sweetalert2/sweetalert2-themes/commit/a4f590e0f97b4e411665a38a54b408c6351d5785))

## [3.0.2](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.0.1...v3.0.2) (2019-11-14)


### Bug Fixes

* **dark:** buttons outline ([631237c](https://github.com/sweetalert2/sweetalert2-themes/commit/631237c0057de9ed6da0dcbbf4632a4d9b361bfd))

## [3.0.1](https://github.com/sweetalert2/sweetalert2-themes/compare/v3.0.0...v3.0.1) (2019-11-06)


### Bug Fixes

* bump sweetalert2 to ^9.1.5 ([bf056e4](https://github.com/sweetalert2/sweetalert2-themes/commit/bf056e4752d649e519c09e0b36d7c9a67dc08e4e))

# [3.0.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v2.2.1...v3.0.0) (2019-11-05)


* BREAKING CHANGE: sweetalert2 v9 ([2205826](https://github.com/sweetalert2/sweetalert2-themes/commit/22058264538493c1309d889908184400d57613c0))


### BREAKING CHANGES

* sweetalert2 v9

## [2.2.1](https://github.com/sweetalert2/sweetalert2-themes/compare/v2.2.0...v2.2.1) (2019-10-17)


### Bug Fixes

* write NPM_TOKEN to ~/.npmrc ([bfe1609](https://github.com/sweetalert2/sweetalert2-themes/commit/bfe1609425c60c9123069db982b521af7aa27c38))

# [2.2.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v2.1.0...v2.2.0) (2019-10-17)


### Features

* Material UI theme ([#21](https://github.com/sweetalert2/sweetalert2-themes/issues/21)) ([77e5513](https://github.com/sweetalert2/sweetalert2-themes/commit/77e5513ecd96e637d09d0c0ba4054fb0c98bebee))

# [2.1.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v2.0.3...v2.1.0) (2019-08-09)


### Features

* Bootstrap 4 theme ([#23](https://github.com/sweetalert2/sweetalert2-themes/issues/23)) ([a802ed3](https://github.com/sweetalert2/sweetalert2-themes/commit/a802ed3))

## [2.0.3](https://github.com/sweetalert2/sweetalert2-themes/compare/v2.0.2...v2.0.3) (2019-05-10)


### Bug Fixes

* **borderless:** use opacity animation instead of trasform ([1d9a7a4](https://github.com/sweetalert2/sweetalert2-themes/commit/1d9a7a4))

## [2.0.2](https://github.com/sweetalert2/sweetalert2-themes/compare/v2.0.1...v2.0.2) (2019-05-10)


### Bug Fixes

* **borderless:** toasts background ([2c0be84](https://github.com/sweetalert2/sweetalert2-themes/commit/2c0be84))

## [2.0.1](https://github.com/sweetalert2/sweetalert2-themes/compare/v2.0.0...v2.0.1) (2019-05-10)


### Bug Fixes

* **borderlesse:** select colors ([4faa389](https://github.com/sweetalert2/sweetalert2-themes/commit/4faa389))
* **semantic-release:** set env.VERSION before building CSS files ([c4b31de](https://github.com/sweetalert2/sweetalert2-themes/commit/c4b31de))

# [2.0.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.3.0...v2.0.0) (2019-05-10)


* BREAKING CHANGE: remove embed-iframe theme, use borderless instead ([6f0b0be](https://github.com/sweetalert2/sweetalert2-themes/commit/6f0b0be))


### BREAKING CHANGES

* remove embed-iframe theme, use borderless instead

# [1.3.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.2.3...v1.3.0) (2019-05-10)


### Features

* add Borderless theme ([#19](https://github.com/sweetalert2/sweetalert2-themes/issues/19)) ([88d878c](https://github.com/sweetalert2/sweetalert2-themes/commit/88d878c))

## [1.2.3](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.2.2...v1.2.3) (2019-05-10)


### Bug Fixes

* add banners (headers) to CSS files ([f49b8af](https://github.com/sweetalert2/sweetalert2-themes/commit/f49b8af))

## [1.2.2](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.2.1...v1.2.2) (2019-05-10)


### Bug Fixes

* depend on sweetalert2@^8.10.5 ([71f703b](https://github.com/sweetalert2/sweetalert2-themes/commit/71f703b))

## [1.2.1](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.2.0...v1.2.1) (2019-05-08)


### Bug Fixes

* CSS files minification ([c8e7e7a](https://github.com/sweetalert2/sweetalert2-themes/commit/c8e7e7a))

# [1.2.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.1.0...v1.2.0) (2019-05-08)


### Features

* add Default theme ([9414c11](https://github.com/sweetalert2/sweetalert2-themes/commit/9414c11))

# [1.1.0](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.0.6...v1.1.0) (2019-05-04)


### Features

* add theme-minimal ([#18](https://github.com/sweetalert2/sweetalert2-themes/issues/18)) ([bb734fe](https://github.com/sweetalert2/sweetalert2-themes/commit/bb734fe))

## [1.0.6](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.0.5...v1.0.6) (2019-05-03)


### Bug Fixes

* **create-new-theme:** remove unnecessary './node_modules/bin/' ([1372e04](https://github.com/sweetalert2/sweetalert2-themes/commit/1372e04))

## [1.0.5](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.0.4...v1.0.5) (2019-04-30)


### Bug Fixes

* remove CSS files from repo ([#8](https://github.com/sweetalert2/sweetalert2-themes/issues/8)) ([480ddaf](https://github.com/sweetalert2/sweetalert2-themes/commit/480ddaf))

## [1.0.4](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.0.3...v1.0.4) (2019-04-30)


### Bug Fixes

* **dark:** backdrop opacity ([#7](https://github.com/sweetalert2/sweetalert2-themes/issues/7)) ([89ac5e5](https://github.com/sweetalert2/sweetalert2-themes/commit/89ac5e5))

## [1.0.3](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.0.2...v1.0.3) (2019-04-29)


### Bug Fixes

* use tilde instead of relative path in [@import](https://github.com/import) ([8fdedd5](https://github.com/sweetalert2/sweetalert2-themes/commit/8fdedd5))

## [1.0.2](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.0.1...v1.0.2) (2019-04-29)


### Bug Fixes

* specify theme directory for npm publish ([03a95e1](https://github.com/sweetalert2/sweetalert2-themes/commit/03a95e1))

## [1.0.1](https://github.com/sweetalert2/sweetalert2-themes/compare/v1.0.0...v1.0.1) (2019-04-29)


### Bug Fixes

* automatically publish all themes ([#3](https://github.com/sweetalert2/sweetalert2-themes/issues/3)) ([fee83e1](https://github.com/sweetalert2/sweetalert2-themes/commit/fee83e1))

# 1.0.0 (2019-04-28)


### Features

* Dark Theme ⚫ ([#2](https://github.com/sweetalert2/sweetalert2-themes/issues/2)) ([bfdb3cb](https://github.com/sweetalert2/sweetalert2-themes/commit/bfdb3cb))
